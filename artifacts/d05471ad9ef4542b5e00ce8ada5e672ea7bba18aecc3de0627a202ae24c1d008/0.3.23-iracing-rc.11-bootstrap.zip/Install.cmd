@echo off
setlocal
set "EVIL_MODE=Setup"
if /I "%~1"=="zurueck" set "EVIL_MODE=Rollback"
if /I "%~1"=="status" set "EVIL_MODE=Status"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0intern\Start-Installation.ps1" -Mode %EVIL_MODE%
set "EVIL_EXIT=%ERRORLEVEL%"
pause
exit /b %EVIL_EXIT%
