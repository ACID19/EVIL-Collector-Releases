# Windows PowerShell 5.1; dot-source only. Does not load or start the plugin.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:CollectorVersion = '0.3.23-iracing-rc.11'
$script:SourceSha = '51151761602eb7cebf7e1e4bd0a96238fb65d62bcd9c6c6f5d96cc43a4f1fa00'
$script:PluginFiles = @('EVILMotorsport.SimHubTelemetry.dll','EVILMotorsport.CollectorUpdateHelper.exe')

function Get-CollectorHash([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Assert-PlainPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.Length -ge 248) { throw 'Pfad zu lang fuer Windows PowerShell/.NET Framework. Paket in einen kuerzeren Ordner entpacken.' }
    $current = $full
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'Verknuepfte Ordner/Dateien werden fuer diesen Test nicht unterstuetzt.'
            }
        }
        $parent = Split-Path -Parent $current
        if ($parent -eq $current) { break }
        $current = $parent
    }
    $full
}
function Get-CollectorChild([string]$Root,[string]$Relative) {
    $rootFull = (Assert-PlainPath $Root).TrimEnd('\')
    if ([IO.Path]::IsPathRooted($Relative)) { throw 'Absoluter Unterpfad blockiert.' }
    $path = Assert-PlainPath (Join-Path $rootFull $Relative)
    if (-not $path.StartsWith($rootFull + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Unterpfad verlaesst Zielordner.' }
    $path
}
function Write-CollectorJson([string]$Path,$Value) {
    $null = Assert-PlainPath $Path
    $tmp = Get-CollectorChild (Split-Path -Parent $Path) ('.evil-' + [guid]::NewGuid().ToString('N') + '.tmp')
    [IO.File]::WriteAllText($tmp,($Value | ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($tmp,$Path,[NullString]::Value) }
    else { [IO.File]::Move($tmp,$Path) }
}
function Read-CollectorJson([string]$Path) {
    $null = Assert-PlainPath $Path
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}
function Assert-CollectorClosed {
    if (Get-Process -Name SimHubWPF,SimHub -ErrorAction SilentlyContinue) {
        throw 'SimHub zuerst vollstaendig beenden, auch im Infobereich neben der Uhr.'
    }
}
function Resolve-CollectorSimHub([string]$Requested) {
    if ($Requested) { $candidates = @($Requested) }
    else {
        $candidates = @()
        foreach ($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles)) {
            if ($base) { $candidates += Join-Path $base 'SimHub' }
        }
    }
    foreach ($candidate in $candidates) {
        $path = Assert-PlainPath $candidate
        if ((Test-Path -LiteralPath (Join-Path $path 'SimHub.Plugins.dll') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $path 'GameReaderCommon.dll') -PathType Leaf)) { return $path }
    }
    throw 'SimHub nicht gefunden. Install.cmd erneut starten und den SimHub-Hauptordner eingeben.'
}
function Get-CollectorReferences([string]$SimHubPath) {
    foreach ($name in @('SimHub.Plugins.dll','GameReaderCommon.dll')) {
        $path = Get-CollectorChild $SimHubPath $name
        $assembly = [Reflection.AssemblyName]::GetAssemblyName($path)
        if ($assembly.Name -ne [IO.Path]::GetFileNameWithoutExtension($name)) { throw 'Unerwartete SimHub-Assembly.' }
        [pscustomobject]@{ name=$name; sha256=Get-CollectorHash $path; assembly=$assembly.FullName }
    }
}
function Build-Collector([string]$Bundle,[string]$Work,[string]$SimHubPath) {
    Assert-CollectorClosed
    $simhub=Resolve-CollectorSimHub $SimHubPath
    $refs=@(Get-CollectorReferences $simhub)
    $payload=Get-CollectorChild $Bundle 'collector-bootstrap-rc11.zip'
    if((Get-CollectorHash $payload) -ne $script:SourceSha){throw 'Bootstrap package hash mismatch.'}
    $output=Get-CollectorChild $Work ('build-'+[guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($output)|Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip=[IO.Compression.ZipFile]::OpenRead($payload)
    try {
        if($zip.Entries.Count -ne 3){throw 'Bootstrap archive invalid.'}
        $seen=@{}
        foreach($entry in $zip.Entries) {
            if($entry.FullName -notin @('package.json','EVILMotorsport.SimHubTelemetry.dll','EVILMotorsport.CollectorUpdateHelper.exe') -or $seen.ContainsKey($entry.FullName) -or $entry.Length -le 0 -or $entry.Length -gt 4194304){throw 'Bootstrap archive invalid.'}
            $seen[$entry.FullName]=$true
            $target=Get-CollectorChild $output $entry.FullName
            $from=$entry.Open();$to=[IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try{$from.CopyTo($to);$to.Flush($true)}finally{$to.Dispose();$from.Dispose()}
        }
    } finally{$zip.Dispose()}
    $metadata=Read-CollectorJson (Join-Path $output 'package.json')
    if($metadata.schema_version -ne 1 -or $metadata.version -ne $script:CollectorVersion){throw 'Bootstrap version mismatch.'}
    foreach($ref in $refs){if($metadata.sdk.($ref.name) -ne $ref.sha256){throw 'This package does not match your SimHub SDK. Nothing installed.'}}
    if($metadata.helper_sha256 -ne (Get-CollectorHash (Join-Path $output 'EVILMotorsport.CollectorUpdateHelper.exe'))){throw 'Bootstrap helper mismatch.'}
    $report=[pscustomobject]@{schema='evil_collector_gaming_build_v1';version=$script:CollectorVersion;source_sha256=$script:SourceSha;computer=$env:COMPUTERNAME;built_at_utc=[DateTime]::UtcNow.ToString('o');simhub=$simhub;references=$refs;build_directory=$output;files=@($script:PluginFiles|ForEach-Object{[pscustomobject]@{name=$_;sha256=Get-CollectorHash (Join-Path $output $_)}});actual_simhub_build=$false;live_test_completed=$false}
    Write-CollectorJson (Join-Path $Work 'build.json') $report
    $report
}
function Assert-CollectorBuild($Build,[string]$Work) {
    if ($Build.schema -ne 'evil_collector_gaming_build_v1' -or $Build.version -ne $script:CollectorVersion -or
        $Build.source_sha256 -ne $script:SourceSha -or $Build.computer -ne $env:COMPUTERNAME) { throw 'Build gehoert nicht zu diesem Paket oder Rechner. Install.cmd erneut ausfuehren.' }
    $output = Get-CollectorChild $Work ([IO.Path]::GetFileName($Build.build_directory))
    if ($output -ne $Build.build_directory -or [IO.Path]::GetFileName($output) -notmatch '^build-[a-f0-9]{32}$') { throw 'Build-Pfad stimmt nicht.' }
    $simhub = Resolve-CollectorSimHub $Build.simhub
    $actual = @(Get-CollectorReferences $simhub)
    if (@($Build.references).Count -ne 2 -or @($Build.files).Count -ne 2) { throw 'Build-Manifest unvollstaendig.' }
    for ($i=0;$i -lt 2;$i++) {
        if ($actual[$i].name -ne $Build.references[$i].name -or $actual[$i].sha256 -ne $Build.references[$i].sha256) { throw 'SimHub wurde seit dem Build veraendert. Erneut bauen.' }
        if ($Build.files[$i].name -ne $script:PluginFiles[$i] -or (Get-CollectorHash (Join-Path $output $script:PluginFiles[$i])) -ne $Build.files[$i].sha256) { throw 'Build-Dateien veraendert. Erneut bauen.' }
    }
}
function Set-CollectorFile([string]$Source,[string]$Target) {
    $null = Assert-PlainPath $Source; $null = Assert-PlainPath $Target
    $staged = Get-CollectorChild (Split-Path -Parent $Target) ('.evil-' + [guid]::NewGuid().ToString('N') + '.new')
    [IO.File]::Copy($Source,$staged,$false)
    if (Test-Path -LiteralPath $Target) { [IO.File]::Replace($staged,$Target,[NullString]::Value) }
    else { [IO.File]::Move($staged,$Target) }
}
function Restore-CollectorFiles($Manifest,[string]$Backup) {
    foreach ($row in $Manifest.files) {
        $target = Get-CollectorChild $Manifest.simhub $row.name
        if ($row.existed) { Set-CollectorFile (Get-CollectorChild $Backup $row.name) $target }
        elseif (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
    }
}
function Install-Collector($Build,[string]$Work) {
    Assert-CollectorClosed; Assert-CollectorBuild $Build $Work
    foreach ($oldProbe in @('EVILCalibrationProbeV2.dll')) {
        if (Test-Path -LiteralPath (Get-CollectorChild $Build.simhub $oldProbe)) { throw 'Separate alte Calibration-Probe gefunden. Vor dem Test erst pruefen; nichts wurde ersetzt.' }
    }
    $same = $true
    foreach ($row in $Build.files) {
        $target = Get-CollectorChild $Build.simhub $row.name
        if (-not (Test-Path -LiteralPath $target) -or (Get-CollectorHash $target) -ne $row.sha256) { $same=$false }
    }
    if ($same) { return [pscustomobject]@{ mode='ALREADY_INSTALLED'; version=$script:CollectorVersion } }
    $backup = Get-CollectorChild $Build.simhub ('EVIL-Collector-Backups\' + [guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    $rows = @()
    foreach ($row in $Build.files) {
        $target = Get-CollectorChild $Build.simhub $row.name
        $exists = Test-Path -LiteralPath $target -PathType Leaf
        $hash = $null
        if ($exists) {
            $hash=Get-CollectorHash $target; $copy=Get-CollectorChild $backup $row.name
            [IO.File]::Copy($target,$copy,$false)
            if ((Get-CollectorHash $copy) -ne $hash) { throw 'Sicherung stimmt nicht; nichts installiert.' }
        }
        $rows += [pscustomobject]@{ name=$row.name; existed=[bool]$exists; previous_sha256=$hash; installed_sha256=$row.sha256 }
    }
    $manifest = [pscustomobject]@{ schema='evil_collector_backup_v1'; computer=$env:COMPUTERNAME; version=$script:CollectorVersion; simhub=$Build.simhub; status='prepared'; files=$rows }
    Write-CollectorJson (Join-Path $backup 'backup.json') $manifest
    try {
        Assert-CollectorClosed
        foreach ($row in $Build.files) { Set-CollectorFile (Join-Path $Build.build_directory $row.name) (Join-Path $Build.simhub $row.name) }
        foreach ($row in $Build.files) { if ((Get-CollectorHash (Join-Path $Build.simhub $row.name)) -ne $row.sha256) { throw 'Installationspruefsumme stimmt nicht.' } }
        $manifest.status='installed'
        Write-CollectorJson (Join-Path $backup 'backup.json') $manifest
        Write-CollectorJson (Join-Path $Work 'installation.json') ([pscustomobject]@{backup=$backup; simhub=$Build.simhub; version=$script:CollectorVersion})
    } catch {
        try { Restore-CollectorFiles $manifest $backup; $manifest.status='failed_restored'; Write-CollectorJson (Join-Path $backup 'backup.json') $manifest }
        catch { throw ('Ruecksicherung unvollstaendig: ' + $_.Exception.Message + '. SimHub geschlossen lassen. Sicherung: ' + $backup) }
        throw 'Installation abgebrochen; bisherige Plugin-Dateien wiederhergestellt.'
    }
    [pscustomobject]@{mode='INSTALLED';version=$script:CollectorVersion;backup=$backup; settings_and_queue='untouched'}
}
function Rollback-Collector([string]$Work) {
    Assert-CollectorClosed
    $pointer = Read-CollectorJson (Join-Path $Work 'installation.json')
    $simhub = Resolve-CollectorSimHub $pointer.simhub
    $backupRoot = Get-CollectorChild $simhub 'EVIL-Collector-Backups'
    $backup = Get-CollectorChild $backupRoot ([IO.Path]::GetFileName($pointer.backup))
    if ($backup -ne $pointer.backup) { throw 'Sicherungspfad stimmt nicht.' }
    $m = Read-CollectorJson (Join-Path $backup 'backup.json')
    if ($m.schema -ne 'evil_collector_backup_v1' -or $m.computer -ne $env:COMPUTERNAME -or $m.simhub -ne $simhub -or $m.version -ne $script:CollectorVersion -or $m.status -ne 'installed' -or @($m.files).Count -ne 2) { throw 'Keine passende abgeschlossene Installation zuruecksetzbar.' }
    for ($i=0;$i -lt 2;$i++) {
        $r=$m.files[$i]
        if ($r.name -ne $script:PluginFiles[$i] -or (Get-CollectorHash (Join-Path $simhub $r.name)) -ne $r.installed_sha256) { throw 'Installiertes Plugin inzwischen veraendert; automatische Rueckkehr blockiert.' }
        if ($r.existed -and (Get-CollectorHash (Join-Path $backup $r.name)) -ne $r.previous_sha256) { throw 'Sicherung veraendert; Rueckkehr blockiert.' }
    }
    Restore-CollectorFiles $m $backup
    foreach ($r in $m.files) {
        $path=Join-Path $simhub $r.name
        if ($r.existed) { if ((Get-CollectorHash $path) -ne $r.previous_sha256) { throw 'Rueckkehrpruefung fehlgeschlagen. SimHub geschlossen lassen.' } }
        elseif (Test-Path -LiteralPath $path) { throw 'Rueckkehrpruefung fehlgeschlagen.' }
    }
    $m.status='rolled_back'; Write-CollectorJson (Join-Path $backup 'backup.json') $m
    [pscustomobject]@{mode='ROLLED_BACK';settings_and_queue='untouched'}
}
