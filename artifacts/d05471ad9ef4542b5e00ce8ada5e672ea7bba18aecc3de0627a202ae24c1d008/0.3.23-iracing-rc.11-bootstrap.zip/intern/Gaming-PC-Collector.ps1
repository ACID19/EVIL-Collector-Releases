[CmdletBinding()]
param([ValidateSet('Build','Install','Rollback','Status')][string]$Mode='Build',[string]$SimHubPath='', [switch]$Elevated)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Collector-Deployment.ps1')
$work = Get-CollectorChild $PSScriptRoot 'work'
try {
    [IO.Directory]::CreateDirectory($work) | Out-Null
    if ($Elevated) {
        $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Administratorrechte fehlen.' }
        if ($Mode -eq 'Install') { $build=Read-CollectorJson (Join-Path $work 'build.json'); Assert-CollectorBuild $build $work; $simhub=$build.simhub }
        elseif ($Mode -eq 'Rollback') { $pointer=Read-CollectorJson (Join-Path $work 'installation.json'); $simhub=Resolve-CollectorSimHub $pointer.simhub }
        else { throw 'Unerwarteter erhoehter Modus.' }
        $backupRoot=Get-CollectorChild $simhub 'EVIL-Collector-Backups'
        [IO.Directory]::CreateDirectory($backupRoot) | Out-Null
        $gate=[IO.File]::Open((Get-CollectorChild $backupRoot 'deployment.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try {
            if ($Mode -eq 'Install') { $result=Install-Collector $build $work }
            else { $result=Rollback-Collector $work }
        } finally { $gate.Dispose() }
        Write-CollectorJson (Join-Path $work 'operation-result.json') ([pscustomobject]@{success=$true;result=$result})
        exit 0
    }
    Write-Host ('EVIL Motorsport - gemeinsamer Collector ' + $script:CollectorVersion) -ForegroundColor Cyan
    if ($Mode -eq 'Build') {
        if (-not $SimHubPath) {
            try { $SimHubPath=Resolve-CollectorSimHub '' }
            catch { $SimHubPath=Read-Host 'SimHub-Hauptordner (z.B. D:\SimHub)' }
        }
        $report=Build-Collector $PSScriptRoot $work $SimHubPath
        Write-Host 'BUILD=PASS; vorgebautes Paket; lokale SimHub-Kompatibilitaet geprueft. Noch nichts installiert.' -ForegroundColor Green
        Write-Host ('SimHub: ' + $report.simhub)
        Write-Host 'Build abgeschlossen. Der Installer setzt mit Sicherung und Installation fort.'
    }
    elseif ($Mode -eq 'Status') {
        $report=Read-CollectorJson (Join-Path $work 'build.json')
        Assert-CollectorBuild $report $work
        $target=Join-Path $report.simhub $script:PluginFiles[0]
        $same=(Test-Path -LiteralPath $target) -and ((Get-CollectorHash $target) -eq $report.files[0].sha256)
        Write-Host ('RC4_DLL_MATCH=' + $same)
        Write-Host ('SIMHUB_RUNNING=' + [bool](Get-Process -Name SimHubWPF,SimHub -ErrorAction SilentlyContinue))
        Write-Host 'DLL-Pruefung bestaetigt keinen Fahrtest. In SimHub EVILTelemetryVersion pruefen.'
    }
    else {
        Assert-CollectorClosed
        if ($Mode -eq 'Install') {
            $report=Read-CollectorJson (Join-Path $work 'build.json'); Assert-CollectorBuild $report $work
            $settings=Join-Path $env:LOCALAPPDATA 'EVIL Motorsport\Telemetry Collector\settings.json'
            if (-not (Test-Path -LiteralPath $settings -PathType Leaf)) { throw 'Keine bestehende Collector-Konfiguration in diesem Windows-Konto. Mit dem bisherigen SimHub-Benutzer starten.' }
            $null=Assert-PlainPath $settings
            $settingsHash=Get-CollectorHash $settings
        }
        $resultPath=Join-Path $work 'operation-result.json'
        if (Test-Path -LiteralPath $resultPath) { Remove-Item -LiteralPath $resultPath -Force }
        $scriptPath=Join-Path $PSScriptRoot 'Gaming-PC-Collector.ps1'
        if ($scriptPath -match '["\r\n]') { throw 'Ungueltiger Paketpfad.' }
        $argsLine='-NoProfile -ExecutionPolicy Bypass -File "{0}" -Mode {1} -Elevated' -f $scriptPath,$Mode
        $process=Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList $argsLine -Wait -PassThru
        if (-not (Test-Path -LiteralPath $resultPath)) { throw 'UAC/Dateikopie nicht abgeschlossen. SimHub geschlossen lassen; kein erneuter Build noetig.' }
        $response=Read-CollectorJson $resultPath
        if (-not $response.success -or $process.ExitCode -ne 0) { throw $response.error }
        if ($Mode -eq 'Install' -and (Get-CollectorHash $settings) -ne $settingsHash) { throw 'Einstellungen wurden zwischenzeitlich extern veraendert. Vor SimHub-Start pruefen.' }
        $response.result | ConvertTo-Json -Depth 5 | Write-Host
        Write-Host 'Fertig. Anleitung zum Fahrtest in START-HIER.md.' -ForegroundColor Green
    }
} catch {
    if ($Elevated) { Write-CollectorJson (Join-Path $work 'operation-result.json') ([pscustomobject]@{success=$false;error=$_.Exception.Message}) }
    else { Write-Host ('FEHLER: ' + $_.Exception.Message) -ForegroundColor Red }
    exit 1
}
