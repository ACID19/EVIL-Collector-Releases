[CmdletBinding()]
param([ValidateSet('Setup','Status','Rollback')][string]$Mode='Setup')
$ErrorActionPreference='Stop'

function Invoke-CollectorStage([ValidateSet('Build','Install','Status','Rollback')][string]$Stage) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Gaming-PC-Collector.ps1') -Mode $Stage
    if ($LASTEXITCODE -ne 0) { throw ('Schritt '+$Stage+' fehlgeschlagen. Der Ablauf wurde angehalten.') }
}
function Invoke-CollectorSetup([ValidateSet('Setup','Status','Rollback')][string]$Action) {
    if ($Action -eq 'Setup') {
        Invoke-CollectorStage Build
        Invoke-CollectorStage Install
        Invoke-CollectorStage Status
        Write-Host 'INSTALLATION=PASS. SimHub jetzt normal starten und die Collector-Version pruefen.' -ForegroundColor Green
    }
    elseif ($Action -eq 'Rollback') { Invoke-CollectorStage Rollback }
    else { Invoke-CollectorStage Status }
}
if ($MyInvocation.InvocationName -ne '.') {
    try { Invoke-CollectorSetup $Mode }
    catch { Write-Host ('FEHLER: '+$_.Exception.Message) -ForegroundColor Red; exit 1 }
}
