# EVIL Collector 0.3.23-iracing-rc.17

SimHub und Spiele schliessen. ZIP vollstaendig in einen kurzen neuen Ordner entpacken, Install.cmd starten und danach SimHub normal oeffnen: Additional plugins → EVIL Motorsport Telemetry → Updates.

Dieses vorgebaute Paket akzeptiert ausschliesslich das gepruefte SimHub-SDK. Bei einer Abweichung bleibt die Installation unveraendert. Kein lokaler Compiler und keine GitHub-Zugangsdaten erforderlich. Stable ist Standard, RC ausdrueckliche Auswahl. Alte Plugin-/Helferdateien werden gesichert; Install.cmd zurueck stellt diese Bootstrap-Installation wieder her, solange keine spaetere Aktualisierung installiert wurde. Die vorhandene PDB bleibt beim Bootstrap erhalten; spaetere binaere Updates sichern und entfernen veraltete Debug-Dateien.

Vorschau, kein FINAL-/Teamrollout.
